
public class Main {
	public static void main(String[] args) {
		Controller starter = new Controller();
		starter.start();
	}
}

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;



import javax.swing.JPanel;


/**
 * View: Contains everything about graphics and images
 * Know size of world, which images to load etc
 *
 * has methods to
 * provide boundaries
 * use proper images for direction
 * load images for all direction (an image should only be loaded once!!! why?)
 **/
class View extends JPanel{
    
    final static int frameWidth = 500;
    final static int frameHeight = 300;
    final static int imgWidth = 165;
    final static int imgHeight = 165;
    
    final int xIncr = 8;
    final int yIncr = 2;
    final int frameCount = 10;
    
    int xloc;
    int yloc;
    int direction;
    
    int picNum = 0;
    BufferedImage[][] pics = new BufferedImage[8][10];
    BufferedImage[] img = new BufferedImage[8];
    JFrame frame;
    
    
    /*
     * the View constructor builds the new JFrame and adds a contentPane, and the specifics of color and dimensions. 
     * It then uses a nested for loop to load a spliced image into a mutidimensional array, each column being a different direction
     */
    View() {
    	frame = new JFrame();
    	frame.getContentPane().add(this);
    	frame.setBackground(Color.gray);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.setSize(frameWidth, frameHeight);
    	frame.setVisible(true);
    	for(int i = 0; i < 8; i++) {
    		img[i] = createImage(i);
	    	for(int j = 0; j < frameCount; j++)
	    		pics[i][j] = img[i].getSubimage(imgWidth*j, 0, imgWidth, imgHeight);
	    	}
    }
    
    /*
     * The paint method calls the drawimage method to display the actual orc running with the most recent 
     * updated location and direction
     */
    public void paint(Graphics g) {
    	picNum = (picNum + 1) % frameCount;
    	g.drawImage(pics[direction][picNum], xloc, yloc, Color.gray, this);
    }
    
    /* 
     * The createimage method imports an image from the src. It takes a counter as input in order to 
     * import all 8 direction orc files into a mutlidimmesional array. 
     */
    private BufferedImage createImage(int counter){
    	BufferedImage bufferedImage;
    	try {
    		switch(counter) {
	    		case 0: 
	        		bufferedImage = ImageIO.read(new File("src/images/orc_forward_north.png"));
	    			break;
	    		case 1: 
	        		bufferedImage = ImageIO.read(new File("src/images/orc_forward_northeast.png"));
	    			break;
	    		case 2: 
	        		bufferedImage = ImageIO.read(new File("src/images/orc_forward_east.png"));
	    			break;
	    		case 3:
	        		bufferedImage = ImageIO.read(new File("src/images/orc_forward_southeast.png"));
	    			break;
	    		case 4: 
	        		bufferedImage = ImageIO.read(new File("src/images/orc_forward_south.png"));
	    			break;
	    		case 5:
	        		bufferedImage = ImageIO.read(new File("src/images/orc_forward_southwest.png"));
	    			break;
	    		case 6: 
	        		bufferedImage = ImageIO.read(new File("src/images/orc_forward_west.png"));
	    			break;
	    		case 7:
	        		bufferedImage = ImageIO.read(new File("src/images/orc_forward_northwest.png"));
	    			break;
	    		default : bufferedImage = null;
    		}
  
    		return bufferedImage;
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    	return null;
    }
    
    /*
     * the update method updates the x and y locations as well as the direction. 
     * it then repaints the image with the updated x, y and direction
     */
    void update(int xloc, int yloc, int  direction) {
    	this.xloc = xloc;
    	this.yloc = yloc;
    	this.direction =  direction;
    	frame.repaint();
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    	return;
    }
    
   
    //returns the frameWidth
    public int getWidth() {
    	return frameWidth;
    }
    
    //returns the frameHeight
    public int getHeight() {
    	return frameHeight;
    } 
    
    //returns the imageHeight
    public int getImageWidth() {
    	return imgWidth;
    }
    
    //returns the imageHeight
    public int getImageHeight() {
    	return imgHeight;
    };
    
  

}
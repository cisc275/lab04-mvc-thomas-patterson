import java.awt.Color;

/**
 * Model: Contains all the state and logic
 * Does not contain anything about images or graphics, must ask view for that
 *
 * has methods to
 *  detect collision with boundaries
 * decide next direction
 * provide direction
 * provide location
 **/

class Model{
	int xloc = 0;
    int yloc = 0;
    int prevDir;
    int direction;
    
    final int xIncr = 8;
    final int yIncr = 2;
    
    int frameWidth;
    int frameHeight;
    int imgWidth;
    int imgHeight;
    
    /*
     * The Model constructor initializes the frame and image dimensions
     */
    Model(int frameWidth, int frameHeight, int imgWidth, int imgHeight){
    	this.frameWidth = frameWidth;
    	this.frameHeight = frameHeight;
    	this.imgWidth = imgWidth;
    	this.imgHeight = imgHeight;
    }
	
    /*
     * checks for any collisosn using the check collision method
     * then calls the move method
     */
	public void updateLocationAndDirection() {
		checkCollison();
		move();
		return;
	}
	
	/*
	 * by comparing the current location of the image to the dimensions of the frame, the 
	 * checkCollision method adjusts the direction to simulate a bounce
	 */
	public void checkCollison() {
		if( xloc < 5 && yloc < 5) {			//close to the top left corner
			 direction =  3; 	//go se
		}
		else if(xloc < 0 && yloc > frameHeight - 5) {  //close to the bottom right corner
			 direction =  1;	 //go ne
			
		}else if(xloc > frameWidth - 5 && yloc < 0) { 		//close to the top right corner
			 direction =  5; 	//go sw
		}else if(xloc > frameWidth - 5 && yloc > frameHeight - 5 ) {		//close to the bottom left corner
			 direction =  7; 		//go nw
		}else if( xloc < 0) {			//hits left side
			if(prevDir == 5) {			//if prev dir is se
				 direction =  7;	//send NW
			}
			else if (prevDir == 7) {// 		if dir is ne
				 direction =  5;	//send SW
			}
			else if(prevDir == 6) {
				 direction =  2;	//send straight EAST
			}
		}
		else if( xloc > frameWidth) {		//hits right side
			if(prevDir == 3) {			//if prev dir is se
				 direction =  5;	//send sw
			}
			else if (prevDir == 1) {// 		if dir is ne
				 direction =  7;	//send nw
			}
			else if(prevDir == 2) {
				 direction =  6;	//send straight west
			}
		}
		else if( yloc < 0) {		//hits the top
			if(prevDir == 1) {		//if prev dir is se
				 direction =  3;	//send sE
			}
			else if (prevDir == 7) {	// 		if dir is ne
				 direction =  5;	//send SW
			}
			else if(prevDir == 0) {
				 direction =  4;	//send straight SOUTH
			}
		}
		else if( yloc > frameHeight) {		//hits the bottom
			if(prevDir == 3) {			//if prev dir is se
				 direction =  1;	//send NE
			}
			else if (prevDir == 5) {	// 		if dir is ne
				 direction =  7;	//send NW
			}
			else if(prevDir == 4) {
				 direction =  0;	//send straight NORTH
			}
		}
		return;
	}
	
	/*
	 * The move method steps the image in the correct direction
	 */
	void move() {
		switch(direction){
			case 0: 				//north
				yloc-=yIncr;
				break;
			case 1: 				//ne
				xloc+=xIncr;
				yloc-=yIncr;
				break;
			case 2: 		//east
				  xloc+=xIncr;
				break;
			case 3:			//se
				  xloc+=xIncr;
				  yloc+=yIncr;
				break;
			case 4: 			//south
				 yloc+=yIncr ;
				break;
			case 5:				//sw
				  xloc-=xIncr;
				  yloc+=yIncr;
				break;
			case 6: 				//west
				  xloc-=xIncr;
				break;
			case 7:					//northwest
				  xloc-=xIncr;
				  yloc-=yIncr;
			break;
		}
		return;
	}
	
	//returns current x location
	int getX() {
		return xloc;
	}
	    
	//returns current y location
    int getY() {
    	return yloc;
	}
	    
	//returns current direction
	int getDirect() {
		return direction;
	}
}
	
